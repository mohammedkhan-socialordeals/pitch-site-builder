import { checkAuth, jsonError } from '@/lib/auth';
import { readBrief } from '@/lib/brief';
import { BUILD_MODEL } from '@/lib/claude';
import { CHROME_SYSTEM, chromeUserContent } from '@/lib/prompts';
import { logoForClaude } from '@/lib/inputs';
import { completeText } from '@/lib/stream';
import { parseChrome } from '@/lib/assemble';

export const maxDuration = 300;
export const dynamic = 'force-dynamic';

// Step 5 (in parallel with the sections): the header with its mobile menu, and the footer.
export async function POST(req) {
  const denied = checkAuth(req);
  if (denied) return denied;
  try {
    const body = await req.json();
    const { brief } = readBrief(body.brief);
    if (!body.design?.plan) throw new Error('Run the art direction step first.');
    const text = await completeText({
      model: BUILD_MODEL,
      max_tokens: 12000,
      system: CHROME_SYSTEM,
      messages: [{ role: 'user', content: chromeUserContent({ brief, audit: body.audit, strategy: body.strategy, design: body.design, logo: logoForClaude(body.logo), google: body.audit?.places?.self || null }) }],
    });
    return Response.json(parseChrome(text));
  } catch (err) {
    return jsonError(err);
  }
}
