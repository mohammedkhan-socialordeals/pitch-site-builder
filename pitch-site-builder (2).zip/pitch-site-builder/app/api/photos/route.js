import { checkAuth, jsonError } from '@/lib/auth';
import { readBrief } from '@/lib/brief';
import { buildLibrary } from '@/lib/library';

export const maxDuration = 300;
export const dynamic = 'force-dynamic';

// Step 3: gather photography (their photos + Pexels stock + optional hero video), compressed.
export async function POST(req) {
  const denied = checkAuth(req);
  if (denied) return denied;
  try {
    const body = await req.json();
    readBrief(body.brief);
    const result = await buildLibrary({
      businessImages: body.audit?.site?.images || [],
      photoQueries: (body.strategy?.photo_queries || []).filter((q) => q?.query),
      videoQuery: body.strategy?.hero_video_query || '',
    });
    return Response.json(result);
  } catch (err) {
    return jsonError(err);
  }
}
