import { checkAuth, jsonError } from '@/lib/auth';
import { readBrief } from '@/lib/brief';
import { BUILD_MODEL } from '@/lib/claude';
import { SECTION_SYSTEM, sectionUserContent } from '@/lib/prompts';
import { libraryForClaude } from '@/lib/inputs';
import { completeText } from '@/lib/stream';
import { parseSection } from '@/lib/assemble';

export const maxDuration = 300;
export const dynamic = 'force-dynamic';

// Step 5: one section of the page. The browser runs several of these at once.
export async function POST(req) {
  const denied = checkAuth(req);
  if (denied) return denied;
  try {
    const body = await req.json();
    const { brief } = readBrief(body.brief);
    const design = body.design;
    const section = design?.plan?.sections?.find((s) => s.id === body.sectionId);
    if (!section) throw new Error('That section isn’t in the plan.');
    const text = await completeText({
      model: BUILD_MODEL,
      max_tokens: 12000,
      system: SECTION_SYSTEM.replaceAll('SECTION_ID', section.id),
      messages: [
        {
          role: 'user',
          content: sectionUserContent({
            brief,
            audit: body.audit,
            strategy: body.strategy,
            design,
            sectionId: section.id,
            library: libraryForClaude(body.library, section.images || []),
            video: body.video || null,
            google: body.audit?.places?.self || null,
            feedback: String(body.feedback || '').slice(0, 800),
          }),
        },
      ],
    });
    return Response.json(parseSection(text, section.id));
  } catch (err) {
    return jsonError(err);
  }
}
