import { checkAuth, jsonError } from '@/lib/auth';
import { readBrief } from '@/lib/brief';
import { scrapeSite } from '@/lib/scrape';
import { runChecklist, summarize } from '@/lib/checklist';
import { runPageSpeed } from '@/lib/pagespeed';
import { findCompetitors } from '@/lib/competitors';

export const maxDuration = 300;
export const dynamic = 'force-dynamic';

// Step 1: read their current site, speed-test it, and pull Google Maps data. Runs in parallel.
export async function POST(req) {
  const denied = checkAuth(req);
  if (denied) return denied;
  try {
    const { brief, meta } = readBrief((await req.json()).brief);

    const [site, speed, places] = await Promise.allSettled([
      scrapeSite(brief.websiteUrl),
      runPageSpeed(brief.websiteUrl, 'mobile'),
      findCompetitors(brief),
    ]);

    const out = { brief, meta, warnings: [] };
    if (site.status === 'fulfilled') {
      const { html, ...facts } = site.value;
      out.site = facts;
      out.checklist = runChecklist(html, site.value);
      out.score = summarize(out.checklist);
    } else {
      out.siteError = site.reason.message;
      out.warnings.push(`Couldn’t read the current site (${site.reason.message}). Claude will research it online instead.`);
    }
    if (speed.status === 'fulfilled') out.speed = speed.value;
    else {
      out.speedError = speed.reason.message;
      out.warnings.push(speed.reason.message);
    }
    if (places.status === 'fulfilled') out.places = places.value;
    else {
      out.places = { source: 'error', self: null, list: [] };
      out.warnings.push(places.reason.message);
    }
    return Response.json(out);
  } catch (err) {
    return jsonError(err, 400);
  }
}
