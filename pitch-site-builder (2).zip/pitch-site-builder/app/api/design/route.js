import { checkAuth, jsonError } from '@/lib/auth';
import { readBrief } from '@/lib/brief';
import { anthropic, BUILD_MODEL } from '@/lib/claude';
import { DESIGN_SYSTEM, designUserContent } from '@/lib/prompts';
import { logoForClaude, libraryForClaude } from '@/lib/inputs';
import { streamText } from '@/lib/stream';

export const maxDuration = 300;
export const dynamic = 'force-dynamic';

// Step 4: art direction. Claude sees the logo and every photo, then writes the plan and design system.
export async function POST(req) {
  const denied = checkAuth(req);
  if (denied) return denied;
  let body, brief, meta;
  try {
    body = await req.json();
    ({ brief, meta } = readBrief(body.brief));
    anthropic();
    if (!body.strategy) throw new Error('Run the research step first.');
    if (!body.logo?.dataUrl) throw new Error('Upload the prospect’s logo first.');
  } catch (err) {
    return jsonError(err, 400);
  }
  const content = designUserContent({
    brief,
    meta,
    audit: body.audit,
    strategy: body.strategy,
    library: libraryForClaude(body.library),
    video: body.video || null,
    logo: logoForClaude(body.logo),
    google: body.audit?.places?.self || null,
  });
  return streamText(req, { model: BUILD_MODEL, max_tokens: 16000, system: DESIGN_SYSTEM, messages: [{ role: 'user', content }] });
}
