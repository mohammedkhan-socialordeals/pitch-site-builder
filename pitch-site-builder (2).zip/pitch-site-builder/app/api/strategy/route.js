import { checkAuth, jsonError } from '@/lib/auth';
import { readBrief } from '@/lib/brief';
import { anthropic, MODEL, extractJson, imageBlockFromDataUrl, friendlyClaudeError } from '@/lib/claude';
import { STRATEGY_SYSTEM, strategyUserText } from '@/lib/prompts';
import { hostOf } from '@/lib/http';

export const maxDuration = 300;
export const dynamic = 'force-dynamic';

// Step 2: Claude reviews the audit + screenshot, searches the web for local competitors, and plans the rebuild.
export async function POST(req) {
  const denied = checkAuth(req);
  if (denied) return denied;
  try {
    const body = await req.json();
    const { brief } = readBrief(body.brief);
    const audit = body.audit || {};

    const content = [];
    const shot = imageBlockFromDataUrl(audit.speed?.screenshot);
    if (shot) content.push({ type: 'text', text: 'Mobile screenshot of their current homepage:' }, shot);
    content.push({ type: 'text', text: strategyUserText({ brief, audit }) });

    const { text, usedWebSearch } = await runWithSearch(content);
    let strategy;
    try {
      strategy = extractJson(text);
    } catch {
      throw new Error('Claude’s plan came back in an unexpected format. Press Retry to run this step again.');
    }

    // Attach real Google ratings to competitors (never trust a model with star counts).
    const places = audit.places?.list || [];
    for (const c of strategy.competitors || []) {
      const match = places.find(
        (p) => (c.url && p.website && hostOf(p.website) === hostOf(c.url)) || p.name.toLowerCase() === String(c.name).toLowerCase()
      );
      if (match) Object.assign(c, { rating: match.rating, reviews: match.reviews, mapsUrl: match.mapsUrl, checklist: match.checklist, url: c.url || match.website });
    }
    return Response.json({ strategy, usedWebSearch });
  } catch (err) {
    return jsonError(friendlyClaudeError(err));
  }
}

async function runWithSearch(content) {
  const client = anthropic();
  const base = { model: MODEL, max_tokens: 8000, system: STRATEGY_SYSTEM };
  const tools = [{ type: 'web_search_20250305', name: 'web_search', max_uses: 6 }];
  let messages = [{ role: 'user', content }];
  let usedWebSearch = true;
  let res;
  try {
    res = await client.messages.create({ ...base, tools, messages });
  } catch (err) {
    // Web search has to be switched on once in the Claude Console. Fall back to no search if it isn't.
    if (err?.status === 400 && /web.?search|tool/i.test(err.message)) {
      usedWebSearch = false;
      res = await client.messages.create({ ...base, messages });
    } else throw err;
  }
  // Long searches can pause mid-turn; continue until Claude finishes.
  for (let i = 0; i < 3 && res.stop_reason === 'pause_turn'; i++) {
    messages = [...messages, { role: 'assistant', content: res.content }];
    res = await client.messages.create({ ...base, tools, messages });
  }
  const text = res.content.filter((b) => b.type === 'text').map((b) => b.text).join('\n');
  return { text, usedWebSearch };
}
