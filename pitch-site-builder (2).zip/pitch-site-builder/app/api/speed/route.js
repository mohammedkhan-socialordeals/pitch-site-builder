import { checkAuth, jsonError } from '@/lib/auth';
import { runPageSpeed } from '@/lib/pagespeed';
import { fetchText, normalizeUrl, sleep } from '@/lib/http';

export const maxDuration = 300;
export const dynamic = 'force-dynamic';

// Step 5: once GitHub Pages is live, run the same Google speed test on the new site.
export async function POST(req) {
  const denied = checkAuth(req);
  if (denied) return denied;
  try {
    const { url, waitForLive } = await req.json();
    const target = normalizeUrl(url);
    if (waitForLive) {
      const started = Date.now();
      let live = false;
      while (Date.now() - started < 150000) {
        const r = await fetchText(target, { timeoutMs: 10000 }).catch(() => null);
        if (r?.ok && /<html/i.test(r.text)) {
          live = true;
          break;
        }
        await sleep(6000);
      }
      if (!live) throw new Error('GitHub Pages is still deploying. Wait a minute, then press Retry.');
      await sleep(4000); // let the CDN settle
    }
    return Response.json({ speed: await runPageSpeed(target, 'mobile') });
  } catch (err) {
    return jsonError(err);
  }
}
