import { checkAuth, jsonError } from '@/lib/auth';
import { readBrief } from '@/lib/brief';
import { publishSite } from '@/lib/github';
import { reportHtml } from '@/lib/report';

export const maxDuration = 300;
export const dynamic = 'force-dynamic';

const jpeg = (dataUrl) => /^data:image\/jpeg;base64,([A-Za-z0-9+/=]+)$/.exec(dataUrl || '')?.[1] || null;

// Step 6: add report.html (the owner's before/after review) to the demo repo.
export async function POST(req) {
  const denied = checkAuth(req);
  if (denied) return denied;
  try {
    const body = await req.json();
    const { brief, meta } = readBrief(body.brief);
    const published = body.published || {};
    if (!published.liveUrl) throw new Error('Publish the site before making the report.');

    const before = body.audit?.speed || null;
    const after = body.after || null;
    const beforeShot = jpeg(before?.screenshot);
    const afterShot = jpeg(after?.screenshot);

    const html = reportHtml({
      brief,
      logo: { ext: String(body.logo?.ext || 'png').replace(/[^a-z]/g, ''), width: body.logo?.width, height: body.logo?.height },
      liveUrl: published.liveUrl,
      before,
      after,
      hasBeforeShot: Boolean(beforeShot),
      hasAfterShot: Boolean(afterShot),
      oldChecks: body.audit?.checklist || null,
      newChecks: published.checklist || null,
      strategy: body.strategy || {},
      google: body.audit?.places?.self || null,
      agency: { name: process.env.AGENCY_NAME, contact: process.env.AGENCY_CONTACT, url: process.env.AGENCY_URL },
    });

    const files = [{ path: 'report.html', content: html }];
    if (beforeShot) files.push({ path: 'assets/before.jpg', content: beforeShot, encoding: 'base64' });
    if (afterShot) files.push({ path: 'assets/after.jpg', content: afterShot, encoding: 'base64' });

    await publishSite({
      repo: meta.repo,
      description: `Website preview for ${brief.businessName} (${brief.location})`,
      homepage: meta.demoUrl,
      files,
      message: `Website review for ${brief.businessName}`,
    });
    return Response.json({ reportUrl: published.liveUrl + 'report.html' });
  } catch (err) {
    return jsonError(err);
  }
}
