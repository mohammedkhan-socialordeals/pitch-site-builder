import { checkAuth, jsonError } from '@/lib/auth';
import { readBrief } from '@/lib/brief';
import { publishSite } from '@/lib/github';
import { robotsTxt, sitemapXml, llmsTxt, readme } from '@/lib/sitefiles';
import { runChecklist, summarize } from '@/lib/checklist';
import { assemblePage, publishResolver } from '@/lib/assemble';
import { renderImages, renderVideo, renderOgImage, creditsMd } from '@/lib/library';

export const maxDuration = 300;
export const dynamic = 'force-dynamic';

const LOGO_TYPES = { png: 1, jpg: 1, webp: 1, svg: 1 };

// Step 6: assemble the final page with optimized local images, render the share image and video,
// and commit everything to GitHub Pages in one go.
export async function POST(req) {
  const denied = checkAuth(req);
  if (denied) return denied;
  try {
    const body = await req.json();
    const { brief, meta } = readBrief(body.brief);
    const { strategy, design, chrome, sections = {}, library = [], logo = {} } = body;
    const google = body.google || null;
    if (!design?.plan || !chrome?.header) throw new Error('The page isn’t finished yet. Run the build steps first.');
    const missing = design.plan.sections.filter((s) => !sections[s.id]?.html).map((s) => s.label || s.id);
    if (missing.length) throw new Error(`These sections aren’t built yet: ${missing.join(', ')}. Rewrite them, then publish.`);
    const m = /^data:([^;]+);base64,(.+)$/.exec(logo.dataUrl || '');
    if (!m || !LOGO_TYPES[logo.ext]) throw new Error('The logo is missing or in an unsupported format.');

    const base = { brief, meta, strategy, design, chrome, sections, library, google, logo, mode: 'publish' };

    // First pass: find which images and whether the video are actually used.
    const draft = assemblePage({ ...base, video: body.video || null, resolve: publishResolver() });

    const heroItem = library.find((i) => i.id === design.plan.hero_image) || library.find((i) => draft.usedImages.includes(i.id));
    const [images, og, videoFile] = await Promise.all([
      renderImages(library, draft.usedImages),
      renderOgImage(heroItem, logo.dataUrl).catch(() => null),
      draft.usesVideo ? renderVideo(body.video).catch(() => null) : null,
    ]);

    // Final pass with real local files (any image that couldn't be fetched keeps its original URL).
    const page = assemblePage({
      ...base,
      meta: { ...meta, hasOg: Boolean(og) },
      video: videoFile ? body.video : null,
      resolve: publishResolver(images.failed),
    });

    const robots = robotsTxt(meta.canonicalUrl);
    const credits = creditsMd(library.filter((i) => page.usedImages.includes(i.id)), videoFile ? body.video : null);
    const files = [
      { path: 'index.html', content: page.html },
      { path: `assets/logo.${logo.ext}`, content: m[2], encoding: 'base64' },
      ...images.files,
      ...(og ? [og.file] : []),
      ...(videoFile ? [videoFile] : []),
      { path: 'robots.txt', content: robots },
      { path: 'sitemap.xml', content: sitemapXml(meta.canonicalUrl) },
      { path: 'llms.txt', content: llmsTxt({ brief, strategy, canonicalUrl: meta.canonicalUrl, google }) },
      { path: 'README.md', content: readme({ brief, liveUrl: meta.demoUrl, canonicalUrl: meta.canonicalUrl }) },
      ...(credits ? [{ path: 'CREDITS.md', content: credits }] : []),
      { path: '.nojekyll', content: '' },
    ];

    const result = await publishSite({
      repo: meta.repo,
      description: `Website preview for ${brief.businessName} (${brief.location})`,
      homepage: meta.demoUrl,
      files,
      message: `Website preview for ${brief.businessName}`,
    });

    const checklist = runChecklist(page.html, { https: true, hasRobots: true, robotsTxt: robots, hasSitemap: true, hasLlms: true });
    return Response.json({ ...result, checklist, score: summarize(checklist), html: page.html, ogPreview: og?.preview || null, files: files.length });
  } catch (err) {
    return jsonError(err);
  }
}
