import { GITHUB_OWNER } from '@/lib/github';
import { MODEL, BUILD_MODEL } from '@/lib/claude';

export const dynamic = 'force-dynamic';

// Tells the page which optional features are switched on.
export function GET() {
  return Response.json({
    owner: GITHUB_OWNER,
    model: MODEL,
    buildModel: BUILD_MODEL,
    passwordRequired: Boolean(process.env.TEAM_PASSWORD),
    hasPlaces: Boolean(process.env.GOOGLE_PLACES_API_KEY),
    hasPageSpeedKey: Boolean(process.env.PAGESPEED_API_KEY),
    hasPexels: Boolean(process.env.PEXELS_API_KEY),
    ready: {
      anthropic: Boolean(process.env.ANTHROPIC_API_KEY),
      github: Boolean(process.env.GITHUB_TOKEN),
    },
  });
}
