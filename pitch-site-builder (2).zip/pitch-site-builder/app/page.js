'use client';

import { useEffect, useMemo, useRef, useState } from 'react';
import QRCode from 'qrcode';
import { assemblePage, parseDesign, previewResolver, seoTitle } from '@/lib/assemble';

const STEPS = [
  { key: 'audit', label: 'Scan their current site', hint: 'Content, structure, Google speed test, Maps profile and reviews' },
  { key: 'strategy', label: 'Research competitors and plan', hint: 'Claude searches the web for rivals in their area' },
  { key: 'photos', label: 'Gather photography', hint: 'Their photos plus licensed stock, compressed for speed' },
  { key: 'design', label: 'Art direction', hint: 'Claude Opus studies the logo and photos, then sets fonts, colors and layout' },
  { key: 'build', label: 'Build the page', hint: 'Header, footer and every section are written at the same time' },
  { key: 'publish', label: 'Publish to GitHub Pages', hint: 'Optimized images, share preview, live link' },
  { key: 'speed', label: 'Speed test the new site', hint: 'Starts once the link is live, about a minute', soft: true },
  { key: 'report', label: 'Publish the owner’s report', hint: 'A before-and-after review page they can open' },
];
const PUBLISH_STEP = STEPS.findIndex((s) => s.key === 'publish');
const BUILD_CONCURRENCY = 4;
const CHROME = '__chrome';
const PASS_KEY = 'psb-team-password';
const RECENT_KEY = 'psb-recent-demos';
const EMPTY_FORM = { businessName: '', websiteUrl: '', industry: '', location: '', phone: '', notes: '' };

export default function Home() {
  const [config, setConfig] = useState(null);
  const [password, setPassword] = useState('');
  const [form, setForm] = useState(EMPTY_FORM);
  const [logo, setLogo] = useState(null);
  const [logoError, setLogoError] = useState('');
  const [steps, setSteps] = useState(STEPS.map(() => 'pending'));
  const [error, setError] = useState(null);
  const [running, setRunning] = useState(false);
  const [audit, setAudit] = useState(null);
  const [strategy, setStrategy] = useState(null);
  const [media, setMedia] = useState(null);
  const [designText, setDesignText] = useState('');
  const [design, setDesign] = useState(null);
  const [parts, setParts] = useState({});
  const [lastDone, setLastDone] = useState('');
  const [published, setPublished] = useState(null);
  const [dirty, setDirty] = useState(false);
  const [afterSpeed, setAfterSpeed] = useState(null);
  const [reportUrl, setReportUrl] = useState('');
  const [view, setView] = useState('desktop');
  const [recent, setRecent] = useState([]);
  const job = useRef({});
  const abortRef = useRef(null);

  useEffect(() => {
    fetch('/api/config').then((r) => r.json()).then(setConfig).catch(() => setConfig(null));
    try {
      setPassword(localStorage.getItem(PASS_KEY) || '');
      setRecent(JSON.parse(localStorage.getItem(RECENT_KEY) || '[]'));
    } catch {}
  }, []);

  const update = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.value }));
  const mark = (i, state) => setSteps((s) => s.map((v, j) => (j === i ? state : v)));
  const setPart = (id, patch) => {
    job.current.parts = { ...job.current.parts, [id]: { ...job.current.parts?.[id], ...patch } };
    setParts(job.current.parts);
  };

  async function api(path, body) {
    const res = await fetch(path, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'x-team-password': password },
      body: JSON.stringify(body),
      signal: abortRef.current?.signal,
    });
    const text = await res.text();
    let data;
    try {
      data = JSON.parse(text);
    } catch {
      throw new Error(res.status === 504 ? 'The server ran out of time on this step. Press Retry.' : `Unexpected server reply (${res.status}).`);
    }
    if (!res.ok) throw new Error(data.error || `Request failed (${res.status}).`);
    return data;
  }

  // Everything Claude needs about the business, without the heavy screenshot.
  const auditLite = () => {
    const a = job.current.audit || {};
    return { ...a, speed: a.speed ? { ...a.speed, screenshot: null } : null };
  };
  const logoPayload = () => {
    const l = job.current.logo;
    return { dataUrl: l.dataUrl, ext: l.ext, width: l.width, height: l.height, svgText: l.svgText || '' };
  };
  const libraryFor = (ids) => (job.current.media?.library || []).map((i) => (ids?.includes(i.id) ? i : { ...i, thumb: undefined }));

  async function buildPart(id, feedback = '') {
    const j = job.current;
    if (id === CHROME) {
      return api('/api/chrome', { brief: j.brief, audit: auditLite(), strategy: j.strategy, design: j.design, logo: logoPayload() });
    }
    const section = j.design.plan.sections.find((s) => s.id === id);
    return api('/api/section', {
      brief: j.brief,
      audit: auditLite(),
      strategy: j.strategy,
      design: j.design,
      sectionId: id,
      library: libraryFor(section?.images || []),
      video: j.media?.video || null,
      feedback,
    });
  }

  const stepFns = {
    async audit() {
      const a = await api('/api/audit', { brief: job.current.brief });
      job.current.audit = a;
      setAudit(a);
    },
    async strategy() {
      const { strategy: s } = await api('/api/strategy', { brief: job.current.brief, audit: job.current.audit });
      job.current.strategy = s;
      setStrategy(s);
    },
    async photos() {
      const m = await api('/api/photos', { brief: job.current.brief, audit: { site: { images: job.current.audit?.site?.images || [] } }, strategy: job.current.strategy });
      job.current.media = m;
      setMedia(m);
    },
    async design() {
      setDesignText('');
      const res = await fetch('/api/design', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-team-password': password },
        body: JSON.stringify({ brief: job.current.brief, audit: auditLite(), strategy: job.current.strategy, library: job.current.media?.library || [], video: job.current.media?.video || null, logo: logoPayload() }),
        signal: abortRef.current?.signal,
      });
      if (!res.ok) {
        const d = await res.json().catch(() => ({}));
        throw new Error(d.error || `Art direction failed (${res.status}).`);
      }
      const reader = res.body.getReader();
      const decoder = new TextDecoder();
      let out = '';
      for (;;) {
        const { done, value } = await reader.read();
        if (done) break;
        out += decoder.decode(value, { stream: true });
        setDesignText(out);
      }
      const err = /<!--PSB:ERROR ([\s\S]*?)-->/.exec(out);
      if (err) throw new Error(err[1].trim());
      if (out.includes('<!--PSB:TRUNCATED-->')) throw new Error('The design system ran past the length limit. Press Retry.');
      const d = parseDesign(out);
      job.current.design = d;
      job.current.parts = {};
      setParts({});
      setDesign(d);
    },
    async build() {
      const ids = [CHROME, ...job.current.design.plan.sections.map((s) => s.id)].filter((id) => !job.current.parts?.[id]?.html);
      ids.forEach((id) => setPart(id, { status: 'queued', error: '' }));
      let next = 0;
      const worker = async () => {
        while (next < ids.length) {
          const id = ids[next++];
          setPart(id, { status: 'active' });
          let lastErr;
          for (let attempt = 0; attempt < 2; attempt++) {
            try {
              const r = await buildPart(id);
              setPart(id, { status: 'done', html: r.html, css: r.css, header: r.header, footer: r.footer, error: '' });
              setLastDone(id);
              lastErr = null;
              break;
            } catch (e) {
              if (e.name === 'AbortError') throw e;
              lastErr = e;
            }
          }
          if (lastErr) setPart(id, { status: 'error', error: lastErr.message });
        }
      };
      await Promise.all(Array.from({ length: Math.min(BUILD_CONCURRENCY, ids.length) }, worker));
      const failed = ids.filter((id) => job.current.parts[id]?.status === 'error');
      if (failed.length) throw new Error(`${failed.length} part${failed.length > 1 ? 's' : ''} didn’t build (${failed.map(partLabel).join(', ')}). Press Retry to rebuild just ${failed.length > 1 ? 'those' : 'that one'}.`);
    },
    async publish() {
      const j = job.current;
      const p = await api('/api/publish', {
        brief: j.brief,
        strategy: j.strategy,
        design: j.design,
        chrome: chromeOf(j.parts),
        sections: sectionsOf(j.parts),
        library: (j.media?.library || []).map((i) => ({ ...i, thumb: undefined })),
        video: j.media?.video || null,
        logo: logoPayload(),
        google: j.audit?.places?.self || null,
      });
      j.published = p;
      setPublished(p);
      setDirty(false);
      saveRecent({ name: j.brief.businessName, liveUrl: p.liveUrl, repoUrl: p.repoUrl, at: Date.now() });
    },
    async speed() {
      job.current.after = null;
      const { speed } = await api('/api/speed', { url: job.current.published.liveUrl, waitForLive: true });
      job.current.after = speed;
      setAfterSpeed(speed);
    },
    async report() {
      const { audit: a, logo: l, published: p } = job.current;
      const { reportUrl: url } = await api('/api/report', {
        brief: job.current.brief,
        logo: { ext: l.ext, width: l.width, height: l.height },
        audit: { speed: a.speed || null, checklist: a.checklist || null, places: { self: a.places?.self || null } },
        strategy: job.current.strategy,
        published: { liveUrl: p.liveUrl, checklist: p.checklist },
        after: job.current.after,
      });
      setReportUrl(url);
      saveRecent({ name: job.current.brief.businessName, liveUrl: p.liveUrl, repoUrl: p.repoUrl, reportUrl: url, at: Date.now() });
    },
  };

  function partLabel(id) {
    if (id === CHROME) return 'header and footer';
    return job.current.design?.plan.sections.find((s) => s.id === id)?.label || id;
  }

  function saveRecent(entry) {
    setRecent((r) => {
      const next = [entry, ...r.filter((x) => x.liveUrl !== entry.liveUrl)].slice(0, 8);
      try {
        localStorage.setItem(RECENT_KEY, JSON.stringify(next));
      } catch {}
      return next;
    });
  }

  async function run(from = 0) {
    if (running) return;
    if (from === 0) {
      const problem = validate(form, logo);
      if (problem) {
        setError({ step: -1, message: problem });
        return;
      }
      job.current = { brief: { ...form }, logo, parts: {} };
      setAudit(null);
      setStrategy(null);
      setMedia(null);
      setDesign(null);
      setDesignText('');
      setParts({});
      setPublished(null);
      setAfterSpeed(null);
      setReportUrl('');
      setDirty(false);
    }
    try {
      localStorage.setItem(PASS_KEY, password);
    } catch {}
    setError(null);
    setRunning(true);
    abortRef.current = new AbortController();
    setSteps((s) => s.map((v, i) => (i < from ? v : 'pending')));
    let current = from;
    try {
      for (; current < STEPS.length; current++) {
        mark(current, 'active');
        try {
          await stepFns[STEPS[current].key]();
          mark(current, 'done');
        } catch (e) {
          // A failed speed test shouldn't stop the report; it just shows "Not tested".
          if (e.name === 'AbortError' || !STEPS[current].soft) throw e;
          mark(current, 'error');
          setError({ step: current, message: e.message });
        }
      }
    } catch (e) {
      if (e.name === 'AbortError') mark(current, 'pending');
      else {
        mark(current, 'error');
        setError({ step: current, message: e.message });
      }
    } finally {
      setRunning(false);
    }
  }

  async function rewrite(id, feedback) {
    setPart(id, { status: 'active', error: '' });
    abortRef.current = abortRef.current || new AbortController();
    try {
      const r = await buildPart(id, feedback);
      setPart(id, { status: 'done', html: r.html, css: r.css, header: r.header, footer: r.footer });
      setLastDone(id);
      if (job.current.published) setDirty(true);
    } catch (e) {
      setPart(id, { status: job.current.parts[id]?.html ? 'done' : 'error', error: e.message });
    }
  }

  async function onLogo(file) {
    setLogoError('');
    if (!file) return;
    try {
      setLogo(await prepareLogo(file));
    } catch (e) {
      setLogo(null);
      setLogoError(e.message);
    }
  }

  const previewDoc = useMemo(() => {
    const j = job.current;
    if (!design || !j.brief || !audit?.meta || !logo) return '';
    try {
      return assemblePage({
        brief: j.brief,
        meta: audit.meta,
        strategy,
        design,
        chrome: chromeOf(parts),
        sections: Object.fromEntries(Object.entries(parts).filter(([k]) => k !== CHROME)),
        library: media?.library || [],
        video: media?.video || null,
        google: audit?.places?.self || null,
        logo,
        resolve: previewResolver,
        mode: 'preview',
      }).html;
    } catch {
      return '';
    }
  }, [design, parts, media, strategy, audit, logo]);

  const anyStarted = steps.some((s) => s !== 'pending');
  const errorStep = error?.step ?? -1;
  const building = running && steps[STEPS.findIndex((s) => s.key === 'build')] === 'active';
  const designing = running && steps[STEPS.findIndex((s) => s.key === 'design')] === 'active';
  const anyRewriting = Object.values(parts).some((p) => p.status === 'active');

  return (
    <div className="app">
      <header className="topbar">
        <div className="brand">
          <BlueprintMark />
          <div>
            <p className="brand-name">Pitch Site Builder</p>
            <p className="brand-sub">Show prospects their new website before the first meeting</p>
          </div>
        </div>
        {config && (
          <p className="model-note">
            Publishing to <a href={`https://github.com/${config.owner}`} target="_blank" rel="noreferrer">github.com/{config.owner}</a>
          </p>
        )}
      </header>

      <main className="layout">
        <aside className="brief">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              run(0);
            }}
          >
            <h1 className="brief-title">Prospect brief</h1>
            {config?.passwordRequired && (
              <Field label="Team password" htmlFor="pw">
                <input id="pw" type="password" autoComplete="current-password" value={password} onChange={(e) => setPassword(e.target.value)} />
              </Field>
            )}
            <Field label="Business name" htmlFor="name">
              <input id="name" required value={form.businessName} onChange={update('businessName')} placeholder="Aventura Dental Arts" />
            </Field>
            <Field label="Current website" htmlFor="url">
              <input id="url" required inputMode="url" value={form.websiteUrl} onChange={update('websiteUrl')} placeholder="aventuradentalarts.com" />
            </Field>
            <div className="row-2">
              <Field label="What they do" htmlFor="ind">
                <input id="ind" required value={form.industry} onChange={update('industry')} placeholder="Cosmetic dentist" />
              </Field>
              <Field label="City and state" htmlFor="loc">
                <input id="loc" required value={form.location} onChange={update('location')} placeholder="Aventura, FL" />
              </Field>
            </div>
            <LogoDrop logo={logo} error={logoError} onFile={onLogo} />
            <Field label="Phone" htmlFor="ph" optional>
              <input id="ph" inputMode="tel" value={form.phone} onChange={update('phone')} placeholder="Only if it’s not on their site" />
            </Field>
            <Field label="Notes for the designer" htmlFor="notes" optional>
              <textarea id="notes" rows={3} value={form.notes} onChange={update('notes')} placeholder="Owner wants a dark, luxurious look. Push veneers and implants. Mention free parking." />
            </Field>

            {error?.step === -1 && (
              <p className="form-error" role="alert">
                {error.message}
              </p>
            )}

            <div className="actions">
              <button className="btn-primary" type="submit" disabled={running}>
                {running ? 'Building…' : anyStarted ? 'Build a new demo' : 'Build demo site'}
              </button>
              {running && (
                <button className="btn-quiet" type="button" onClick={() => abortRef.current?.abort()}>
                  Stop
                </button>
              )}
            </div>
            <SetupNotices config={config} />
          </form>

          {anyStarted && (
            <ol className="steps" aria-label="Progress">
              {STEPS.map((s, i) => (
                <li key={s.key} className={`step step-${steps[i]}`}>
                  <StepIcon state={steps[i]} n={i + 1} />
                  <div>
                    <p className="step-label">{s.label}</p>
                    <p className="step-hint">{steps[i] === 'error' && errorStep === i ? error.message : s.hint}</p>
                    {steps[i] === 'error' && errorStep === i && !running && (
                      <button className="btn-link" type="button" onClick={() => run(i)}>
                        Retry this step
                      </button>
                    )}
                  </div>
                </li>
              ))}
            </ol>
          )}

          {audit?.warnings?.length > 0 && (
            <div className="warnings">
              {audit.warnings.map((w) => (
                <p key={w}>{w}</p>
              ))}
            </div>
          )}

          {recent.length > 0 && (
            <section className="recent" aria-labelledby="recent-h">
              <h2 id="recent-h">Recent demos</h2>
              <ul>
                {recent.map((r) => (
                  <li key={r.liveUrl}>
                    <a href={r.liveUrl} target="_blank" rel="noreferrer">
                      {r.name}
                    </a>
                    {r.reportUrl ? (
                      <a className="recent-report" href={r.reportUrl} target="_blank" rel="noreferrer">
                        Report
                      </a>
                    ) : (
                      <span>{new Date(r.at).toLocaleDateString()}</span>
                    )}
                  </li>
                ))}
              </ul>
            </section>
          )}
        </aside>

        <div className="workspace">
          <Stage
            previewDoc={previewDoc}
            designText={designText}
            designing={designing}
            building={building}
            running={running}
            parts={parts}
            plan={design?.plan}
            lastDone={lastDone}
            published={published}
            reportUrl={reportUrl}
            view={view}
            setView={setView}
            demoUrl={audit?.meta?.demoUrl}
          />

          {design && (
            <SectionList
              plan={design.plan}
              parts={parts}
              locked={running}
              dirty={dirty}
              onRewrite={rewrite}
              onPublish={() => run(PUBLISH_STEP)}
              publishDisabled={running || anyRewriting}
            />
          )}

          {media?.library?.length > 0 && <PhotoStrip media={media} plan={design?.plan} />}

          {published && <SharePanel published={published} reportUrl={reportUrl} brief={job.current.brief} strategy={strategy} />}

          {(audit || published) && <Scorecard audit={audit} after={afterSpeed} afterState={steps[STEPS.findIndex((s) => s.key === 'speed')]} />}
          {(audit?.checklist || published?.checklist) && <Checklist before={audit?.checklist} after={published?.checklist} />}
          {strategy?.old_site_issues?.length > 0 && <Issues issues={strategy.old_site_issues} />}
          {strategy?.competitors?.length > 0 && <Competitors list={strategy.competitors} location={job.current.brief?.location} />}
          {published && (
            <Pitch brief={job.current.brief} strategy={strategy} audit={audit} published={published} after={afterSpeed} reportUrl={reportUrl} html={published.html || ''} />
          )}
        </div>
      </main>
    </div>
  );
}

const chromeOf = (parts) => (parts?.[CHROME]?.header ? { header: parts[CHROME].header, footer: parts[CHROME].footer, css: parts[CHROME].css } : null);
const sectionsOf = (parts) => Object.fromEntries(Object.entries(parts || {}).filter(([k, v]) => k !== CHROME && v.html).map(([k, v]) => [k, { html: v.html, css: v.css }]));

/* ---------- Stage: the live build ---------- */

function Stage({ previewDoc, designText, designing, building, running, parts, plan, lastDone, published, reportUrl, view, setView, demoUrl }) {
  const frameRef = useRef(null);
  const codeRef = useRef(null);
  const showCode = designing && !previewDoc;
  const address = published?.liveUrl || demoUrl || 'Your new demo will appear here';
  const total = plan ? plan.sections.length + 1 : 0;
  const done = Object.values(parts).filter((p) => p.status === 'done').length;

  useEffect(() => {
    if (codeRef.current) codeRef.current.scrollTop = codeRef.current.scrollHeight;
  }, [designText]);

  // While building, jump to the section that just finished.
  function follow() {
    if (!running || !lastDone || lastDone === CHROME) return;
    try {
      frameRef.current.contentDocument.getElementById(lastDone)?.scrollIntoView({ block: 'start' });
    } catch {}
  }

  return (
    <section className="stage" aria-label="Website preview">
      <div className="stage-bar">
        <div className="view-toggle" role="group" aria-label="Preview size">
          <button type="button" aria-pressed={view === 'desktop'} onClick={() => setView('desktop')}>
            Desktop
          </button>
          <button type="button" aria-pressed={view === 'mobile'} onClick={() => setView('mobile')}>
            Phone
          </button>
        </div>
        {designing && <p className="build-meter">Designing the system, {(designText.length / 1024).toFixed(1)} KB written</p>}
        {building && (
          <p className="build-meter">
            Building, {done} of {total} parts ready
          </p>
        )}
        {published && (
          <div className="stage-links">
            <a href={published.liveUrl} target="_blank" rel="noreferrer">
              Open live site
            </a>
            {reportUrl && (
              <a href={reportUrl} target="_blank" rel="noreferrer">
                Owner’s report
              </a>
            )}
            <a href={published.repoUrl} target="_blank" rel="noreferrer">
              GitHub
            </a>
          </div>
        )}
      </div>

      <div className={`browser browser-${view}`}>
        <div className="browser-chrome">
          <span className={`lock ${published ? 'lock-on' : ''}`} aria-hidden="true">
            <svg viewBox="0 0 16 16" width="12" height="12"><path d="M4.5 7V5a3.5 3.5 0 0 1 7 0v2h.5a1 1 0 0 1 1 1v6a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V8a1 1 0 0 1 1-1zm1.5 0h4V5a2 2 0 1 0-4 0z" fill="currentColor" /></svg>
          </span>
          <span className="address">{address}</span>
          {published && <CopyButton text={published.liveUrl} label="Copy link" />}
        </div>
        <div className="browser-body">
          {showCode && (
            <pre className="code-stream" ref={codeRef} aria-live="off">
              {designText.slice(-2600)}
            </pre>
          )}
          {previewDoc ? (
            <iframe
              key={running ? 'building' : 'final'}
              ref={frameRef}
              title="New website preview"
              srcDoc={previewDoc}
              sandbox={running ? 'allow-same-origin' : 'allow-scripts allow-popups'}
              onLoad={follow}
            />
          ) : (
            !showCode && (
              <div className="stage-empty">
                <div className="wire" aria-hidden="true">
                  <div className="wire-nav"><span /><span /><span /><span /></div>
                  <div className="wire-hero"><span /><span /><span /></div>
                  <div className="wire-cols"><span /><span /><span /></div>
                </div>
                <div className="stage-empty-copy">
                  <p className="stage-empty-title">Fill in the prospect brief, then press Build demo site.</p>
                  <p>You’ll watch the art direction get written, then every section of the new site appear here. A finished demo takes about eight minutes.</p>
                </div>
              </div>
            )
          )}
        </div>
      </div>
    </section>
  );
}

/* ---------- Sections: status, rewrite with notes, publish changes ---------- */

function SectionList({ plan, parts, locked, dirty, onRewrite, onPublish, publishDisabled }) {
  const [open, setOpen] = useState('');
  const [notes, setNotes] = useState('');
  const rows = [{ id: CHROME, label: 'Header and footer', kind: 'menu, contact details' }, ...plan.sections];
  return (
    <section className="panel" aria-labelledby="sections-h">
      <div className="panel-head panel-head-row">
        <div>
          <h2 id="sections-h">Sections</h2>
          <p>Not quite right? Rewrite any part with a note, then publish the changes.</p>
        </div>
        {dirty && (
          <button className="btn-primary" type="button" onClick={onPublish} disabled={publishDisabled}>
            Publish changes
          </button>
        )}
      </div>
      <ul className="parts">
        {rows.map((s) => {
          const p = parts[s.id] || {};
          const status = p.status || 'pending';
          return (
            <li key={s.id} className={`part part-${status}`}>
              <div className="part-row">
                <StepIcon state={status === 'queued' ? 'pending' : status} n="" />
                <div className="part-name">
                  <p>{s.label || s.id}</p>
                  <p className="part-kind">
                    {s.kind}
                    {s.interactions?.length ? `: ${s.interactions.map((x) => String(x).replace(/^data-/, '').split(/[\s=]/)[0]).filter((x, i, arr) => x && arr.indexOf(x) === i).slice(0, 4).join(', ')}` : ''}
                  </p>
                </div>
                {!locked && (status === 'done' || status === 'error') && open !== s.id && (
                  <button
                    type="button"
                    className="btn-chip"
                    onClick={() => {
                      setOpen(s.id);
                      setNotes('');
                    }}
                  >
                    Rewrite
                  </button>
                )}
              </div>
              {p.error && <p className="part-error">{p.error}</p>}
              {open === s.id && (
                <form
                  className="part-form"
                  onSubmit={(e) => {
                    e.preventDefault();
                    onRewrite(s.id, notes);
                    setOpen('');
                  }}
                >
                  <label htmlFor={`fb-${s.id}`} className="sr-only">
                    What should change in {s.label || s.id}?
                  </label>
                  <input id={`fb-${s.id}`} value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="What should change? e.g. bigger photo, darker, mention financing" />
                  <button className="btn-primary" type="submit">
                    Rewrite
                  </button>
                  <button className="btn-quiet" type="button" onClick={() => setOpen('')}>
                    Cancel
                  </button>
                </form>
              )}
            </li>
          );
        })}
      </ul>
    </section>
  );
}

function PhotoStrip({ media, plan }) {
  const usedHero = plan?.hero_image;
  const stock = media.library.some((i) => i.source === 'stock');
  return (
    <section className="panel" aria-labelledby="photos-h">
      <div className="panel-head">
        <h2 id="photos-h">Photography</h2>
        <p>
          {media.library.length} photos{media.video ? ' and a hero video' : ''}, compressed for speed.
          {stock ? ' Stock images are from Pexels and free to use; swap in real photos of the business before launch.' : ''}
        </p>
      </div>
      <ul className="photo-strip">
        {media.library.map((i) => (
          <li key={i.id}>
            <img src={i.thumb} alt={i.alt || i.id} width="180" height={Math.round((180 * i.h) / i.w)} loading="lazy" />
            <span className={`photo-tag photo-${i.source}`}>
              {i.id === usedHero ? 'Hero, ' : ''}
              {i.source === 'stock' ? 'stock' : 'their photo'}
            </span>
          </li>
        ))}
      </ul>
      {media.notes?.length > 0 && <p className="photo-note">{media.notes.join(' ')}</p>}
    </section>
  );
}

function SharePanel({ published, reportUrl, brief, strategy }) {
  const [qr, setQr] = useState('');
  const url = published.liveUrl;
  useEffect(() => {
    QRCode.toString(url, { type: 'svg', margin: 1, errorCorrectionLevel: 'M', color: { dark: '#16224f', light: '#ffffff' } })
      .then(setQr)
      .catch(() => setQr(''));
  }, [url]);
  const msg = `Hi! Here’s a preview of your new website: ${url}${reportUrl ? `\n\nAnd a quick review of how it compares with your current site: ${reportUrl}` : ''}`;
  const subject = `Your new website preview, ${brief.businessName}`;
  return (
    <section className="panel share" aria-labelledby="share-h">
      <div className="panel-head">
        <h2 id="share-h">Share with the client</h2>
        <p>Scan the code in a meeting, or send the link. Texted and emailed links show the preview card.</p>
      </div>
      <div className="share-grid">
        <div className="qr" aria-label="QR code for the live site" role="img" dangerouslySetInnerHTML={{ __html: qr }} />
        <div className="share-main">
          <div className="share-link">
            <input readOnly value={url} aria-label="Live site link" onFocus={(e) => e.target.select()} />
            <CopyButton text={url} label="Copy link" primary />
          </div>
          <div className="share-buttons">
            <a className="btn-quiet" href={`sms:?&body=${encodeURIComponent(msg)}`}>
              Text it
            </a>
            <a className="btn-quiet" href={`mailto:?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(msg)}`}>
              Email it
            </a>
            <a className="btn-quiet" href={`https://wa.me/?text=${encodeURIComponent(msg)}`} target="_blank" rel="noreferrer">
              WhatsApp
            </a>
            {reportUrl && (
              <a className="btn-quiet" href={reportUrl} target="_blank" rel="noreferrer">
                Open report
              </a>
            )}
          </div>
          {published.ogPreview && (
            <figure className="og-card">
              <img src={published.ogPreview} alt="Preview card shown when the link is shared" width="600" height="315" />
              <figcaption>
                <span className="og-title">{seoTitle(brief, strategy)}</span>
                <span className="og-domain">{new URL(url).hostname}</span>
              </figcaption>
            </figure>
          )}
        </div>
      </div>
    </section>
  );
}

/* ---------- Results ---------- */

function Scorecard({ audit, after, afterState }) {
  const before = audit?.speed;
  const rows = [
    ['Performance', 'performance'],
    ['SEO', 'seo'],
    ['Accessibility', 'accessibility'],
    ['Best practices', 'bestPractices'],
  ];
  const afterLabel = afterState === 'active' ? 'Testing…' : afterState === 'error' ? 'Retry' : '—';
  return (
    <section className="panel" aria-labelledby="score-h">
      <div className="panel-head">
        <h2 id="score-h">Google PageSpeed on a phone</h2>
        <p>The same test Google uses to judge page experience. Higher is better, 90+ is excellent.</p>
      </div>
      <div className="score-wrap">
        {before?.screenshot && (
          <figure className="old-shot">
            <img src={before.screenshot} alt="Their current homepage on a phone" width="206" height="440" />
            <figcaption>Their site today</figcaption>
          </figure>
        )}
        <div className="table-scroll">
          <table className="score-table">
            <thead>
              <tr>
                <th scope="col">Score</th>
                <th scope="col" className="col-before">Current site</th>
                <th scope="col" className="col-after">New site</th>
              </tr>
            </thead>
            <tbody>
              {rows.map(([label, k]) => (
                <tr key={k}>
                  <th scope="row">{label}</th>
                  <td>{before ? <Score v={before[k]} /> : <span className="muted">{audit?.speedError ? 'Not tested' : '—'}</span>}</td>
                  <td>{after ? <Score v={after[k]} /> : <span className="muted">{afterLabel}</span>}</td>
                </tr>
              ))}
              <tr>
                <th scope="row">Main content visible after</th>
                <td>{before?.lcp?.display || '—'}</td>
                <td>{after?.lcp?.display || <span className="muted">{afterLabel}</span>}</td>
              </tr>
              <tr>
                <th scope="row">Page frozen while loading</th>
                <td>{before?.tbt?.display || '—'}</td>
                <td>{after?.tbt?.display || <span className="muted">{afterLabel}</span>}</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </section>
  );
}

function Score({ v }) {
  if (v == null) return <span className="muted">—</span>;
  const band = v >= 90 ? 'good' : v >= 50 ? 'ok' : 'poor';
  return (
    <span className={`score score-${band}`}>
      <span className="score-num">{v}</span>
      <span className="score-bar" aria-hidden="true">
        <span style={{ width: `${v}%` }} />
      </span>
    </span>
  );
}

const GROUP_INFO = {
  SEO: 'Ranking on Google',
  AEO: 'Answer engines: AI Overviews, featured snippets, voice',
  GEO: 'Generative engines: ChatGPT, Claude, Perplexity, Gemini',
  Speed: 'Page speed',
  Trust: 'Credibility signals customers look for',
};

function Checklist({ before, after }) {
  const base = after || before;
  const byId = (list) => Object.fromEntries((list || []).map((c) => [c.id, c]));
  const b = byId(before);
  const a = byId(after);
  const count = (list) => (list ? `${list.filter((c) => c.pass).length} of ${list.length}` : '—');
  const groups = [...new Set(base.map((c) => c.group))];
  return (
    <section className="panel" aria-labelledby="check-h">
      <div className="panel-head">
        <h2 id="check-h">SEO, AEO and GEO checklist</h2>
        <p>
          Current site passes <strong className="t-before">{count(before)}</strong>
          {after ? (
            <>
              . The new site passes <strong className="t-after">{count(after)}</strong>.
            </>
          ) : (
            '.'
          )}
        </p>
      </div>
      <div className="table-scroll">
        <table className="check-table">
          <thead>
            <tr>
              <th scope="col">Check</th>
              <th scope="col" className="col-before">Current site</th>
              <th scope="col" className="col-after">New site</th>
            </tr>
          </thead>
          {groups.map((g) => (
            <tbody key={g}>
              <tr className="group-row">
                <th colSpan={3} scope="colgroup">
                  {g} <span>{GROUP_INFO[g]}</span>
                </th>
              </tr>
              {base
                .filter((c) => c.group === g)
                .map((c) => (
                  <tr key={c.id}>
                    <th scope="row">{c.label}</th>
                    <td><Mark c={b[c.id]} /></td>
                    <td><Mark c={a[c.id]} /></td>
                  </tr>
                ))}
            </tbody>
          ))}
        </table>
      </div>
    </section>
  );
}

function Mark({ c }) {
  if (!c) return <span className="muted">—</span>;
  return (
    <span className={`mark ${c.pass ? 'mark-pass' : 'mark-fail'}`}>
      {c.pass ? (
        <svg viewBox="0 0 16 16" width="16" height="16" role="img" aria-label="Pass"><path d="M3 8.5l3 3 7-7" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" /></svg>
      ) : (
        <svg viewBox="0 0 16 16" width="16" height="16" role="img" aria-label="Missing"><path d="M4 4l8 8M12 4l-8 8" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" /></svg>
      )}
      {c.detail && <span className="mark-detail">{c.detail}</span>}
    </span>
  );
}

function Issues({ issues }) {
  return (
    <section className="panel" aria-labelledby="issues-h">
      <div className="panel-head">
        <h2 id="issues-h">What’s holding their site back</h2>
        <p>Talking points for the call, ordered by how much they cost the business.</p>
      </div>
      <ul className="issues">
        {issues.map((it, i) => (
          <li key={i}>
            <span className={`area area-${String(it.area).toLowerCase().split(/\W/)[0]}`}>{it.area}</span>
            <div>
              <p className="issue-what">{it.issue}</p>
              <p className="issue-why">{it.why_it_matters}</p>
              <p className="issue-fix">
                <span>New site:</span> {it.fix}
              </p>
            </div>
          </li>
        ))}
      </ul>
    </section>
  );
}

function Competitors({ list, location }) {
  return (
    <section className="panel" aria-labelledby="comp-h">
      <div className="panel-head">
        <h2 id="comp-h">Competitors{location ? ` in ${location}` : ''}</h2>
        <p>Ratings come straight from Google Maps when available.</p>
      </div>
      <ul className="competitors">
        {list.map((c, i) => (
          <li key={i}>
            <div className="comp-head">
              {c.url ? (
                <a href={c.url} target="_blank" rel="noreferrer">
                  {c.name}
                </a>
              ) : (
                <span>{c.name}</span>
              )}
              {c.rating != null && (
                <span className="rating">
                  {c.rating} stars, {c.reviews} reviews
                </span>
              )}
              {c.checklist && (
                <span className="comp-score">
                  passes {c.checklist.passed} of {c.checklist.total} checks
                </span>
              )}
            </div>
            <dl>
              <div><dt>Doing better</dt><dd>{c.doing_better}</dd></div>
              <div><dt>Weak spot</dt><dd>{c.weak_spot}</dd></div>
              <div><dt>How we win</dt><dd>{c.how_we_win}</dd></div>
            </dl>
          </li>
        ))}
      </ul>
    </section>
  );
}

function Pitch({ brief, strategy, audit, published, after, reportUrl, html }) {
  const draft = useMemo(() => composePitch({ brief, strategy, audit, published, after, reportUrl }), [brief, strategy, audit, published, after, reportUrl]);
  const [text, setText] = useState(draft);
  useEffect(() => setText(draft), [draft]);

  function download() {
    const blob = new Blob([html], { type: 'text/html' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'index.html';
    a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 2000);
  }

  return (
    <section className="panel" aria-labelledby="pitch-h">
      <div className="panel-head">
        <h2 id="pitch-h">Message to the owner</h2>
        <p>Edit, copy and send. Speed numbers and the report link fill in as the last steps finish.</p>
      </div>
      <textarea className="pitch-text" rows={14} value={text} onChange={(e) => setText(e.target.value)} aria-label="Message to the owner" />
      <div className="actions">
        <CopyButton text={text} label="Copy message" primary />
        <button type="button" className="btn-quiet" onClick={download}>
          Download index.html
        </button>
      </div>
    </section>
  );
}

/* ---------- Small pieces ---------- */

function SetupNotices({ config }) {
  if (!config) return null;
  const notes = [];
  if (!config.ready.anthropic) notes.push(['bad', 'ANTHROPIC_API_KEY isn’t set, so Claude can’t run yet.']);
  if (!config.ready.github) notes.push(['bad', 'GITHUB_TOKEN isn’t set, so demos can’t be published yet.']);
  if (!config.hasPexels) notes.push(['info', 'Professional photography is off. Add a free PEXELS_API_KEY for stock photos and a hero video. Without it, demos use only the prospect’s own photos.']);
  if (!config.hasPlaces) notes.push(['info', 'Google data is off. Add GOOGLE_PLACES_API_KEY for real reviews, hours, star ratings and nearby competitors.']);
  if (!config.hasPageSpeedKey) notes.push(['info', 'Speed tests use Google’s shared free limit. Add PAGESPEED_API_KEY so tests never get blocked.']);
  if (!notes.length) return null;
  return (
    <div className="notices">
      {notes.map(([kind, t]) => (
        <p key={t} className={`notice notice-${kind}`}>{t}</p>
      ))}
    </div>
  );
}

function Field({ label, htmlFor, optional, children }) {
  return (
    <div className="field">
      <label htmlFor={htmlFor}>
        {label}
        {optional && <span className="optional">optional</span>}
      </label>
      {children}
    </div>
  );
}

function LogoDrop({ logo, error, onFile }) {
  const [over, setOver] = useState(false);
  return (
    <div className="field">
      <span className="label" id="logo-label">Logo</span>
      <label
        className={`drop ${over ? 'drop-over' : ''} ${logo ? 'drop-has' : ''}`}
        onDragOver={(e) => {
          e.preventDefault();
          setOver(true);
        }}
        onDragLeave={() => setOver(false)}
        onDrop={(e) => {
          e.preventDefault();
          setOver(false);
          onFile(e.dataTransfer.files?.[0]);
        }}
      >
        <input type="file" accept="image/png,image/jpeg,image/webp,image/svg+xml" aria-labelledby="logo-label" onChange={(e) => onFile(e.target.files?.[0])} />
        {logo ? (
          <>
            <img src={logo.dataUrl} alt="" />
            <span>
              {logo.name}
              <small>Click to replace</small>
            </span>
          </>
        ) : (
          <span>
            Drop the logo here or click to choose
            <small>PNG, JPG, WebP or SVG. Colors are pulled from it.</small>
          </span>
        )}
      </label>
      {error && <p className="field-error">{error}</p>}
    </div>
  );
}

function StepIcon({ state, n }) {
  if (state === 'done')
    return (
      <span className="step-icon">
        <svg viewBox="0 0 16 16" width="14" height="14" aria-label="Done" role="img"><path d="M3 8.5l3 3 7-7" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" /></svg>
      </span>
    );
  if (state === 'active') return <span className="step-icon"><span className="spinner" aria-label="In progress" role="img" /></span>;
  if (state === 'error') return <span className="step-icon" aria-label="Failed" role="img">!</span>;
  return <span className="step-icon">{n}</span>;
}

function CopyButton({ text, label, primary }) {
  const [copied, setCopied] = useState(false);
  return (
    <button
      type="button"
      className={primary ? 'btn-primary' : 'btn-chip'}
      onClick={async () => {
        try {
          await navigator.clipboard.writeText(text);
          setCopied(true);
          setTimeout(() => setCopied(false), 1600);
        } catch {}
      }}
    >
      {copied ? 'Copied' : label}
    </button>
  );
}

function BlueprintMark() {
  return (
    <svg className="mark-logo" viewBox="0 0 40 40" width="40" height="40" aria-hidden="true">
      <rect width="40" height="40" rx="9" fill="#2443C4" />
      <path d="M8 13h24M8 13v17h24V13" fill="none" stroke="#fff" strokeWidth="2" />
      <path d="M12 18h9M12 22h6M24 18h4v8h-4z" fill="none" stroke="#fff" strokeWidth="1.6" opacity=".75" />
      <circle cx="11" cy="10" r="1.2" fill="#fff" />
    </svg>
  );
}

/* ---------- Helpers ---------- */

function validate(form, logo) {
  if (!form.businessName.trim()) return 'Add the business name.';
  if (!form.websiteUrl.trim()) return 'Add their current website.';
  if (!form.industry.trim()) return 'Add what they do, like “emergency plumber”.';
  if (!form.location.trim()) return 'Add the city and state, like “Glendora, CA”.';
  if (!logo) return 'Upload their logo so the design can match their brand.';
  return null;
}

async function prepareLogo(file) {
  if (file.size > 10 * 1024 * 1024) throw new Error('That file is over 10 MB. Use a smaller logo file.');
  if (file.type === 'image/svg+xml' || /\.svg$/i.test(file.name)) {
    const svgText = await file.text();
    if (!/<svg[\s>]/i.test(svgText)) throw new Error('That SVG file doesn’t contain a drawing.');
    const vb = /viewBox=["']\s*[-\d.]+[\s,]+[-\d.]+[\s,]+([\d.]+)[\s,]+([\d.]+)/i.exec(svgText);
    const dataUrl = 'data:image/svg+xml;base64,' + btoa(unescape(encodeURIComponent(svgText)));
    return { name: file.name, ext: 'svg', mime: 'image/svg+xml', dataUrl, svgText, width: vb ? Math.round(+vb[1]) : 400, height: vb ? Math.round(+vb[2]) : 160 };
  }
  let bitmap;
  try {
    bitmap = await createImageBitmap(file);
  } catch {
    throw new Error('That image couldn’t be opened. Use a PNG, JPG, WebP or SVG logo.');
  }
  // Shrink to 512px so the demo stays fast and the upload stays small.
  const scale = Math.min(1, 512 / Math.max(bitmap.width, bitmap.height));
  const w = Math.max(1, Math.round(bitmap.width * scale));
  const h = Math.max(1, Math.round(bitmap.height * scale));
  const canvas = document.createElement('canvas');
  canvas.width = w;
  canvas.height = h;
  canvas.getContext('2d').drawImage(bitmap, 0, 0, w, h);
  let dataUrl = canvas.toDataURL('image/webp', 0.9);
  let ext = 'webp';
  let mime = 'image/webp';
  if (!dataUrl.startsWith('data:image/webp')) {
    dataUrl = canvas.toDataURL('image/png');
    ext = 'png';
    mime = 'image/png';
  }
  return { name: file.name, ext, mime, dataUrl, width: w, height: h };
}

function composePitch({ brief, strategy, audit, published, after, reportUrl }) {
  const before = audit?.speed;
  const lines = [`Hi ${brief.businessName} team,`, '', `I put together a free preview of what your website could look like: ${published.liveUrl}`, ''];
  if (reportUrl) lines.push(`And a short review comparing it with your current site and your local competitors: ${reportUrl}`, '');
  if (strategy?.pitch_summary) lines.push(strategy.pitch_summary, '');
  lines.push('What changes:');
  if (before?.performance != null && after?.performance != null) {
    lines.push(`- Google mobile speed score goes from ${before.performance} to ${after.performance}`);
  }
  if (before?.lcp?.display && after?.lcp?.display) {
    lines.push(`- Main content shows in ${after.lcp.display} instead of ${before.lcp.display}`);
  }
  if (audit?.score && published?.score) {
    lines.push(`- Passes ${published.score.passed} of ${published.score.total} search and AI-visibility checks (today: ${audit.score.passed})`);
  }
  (strategy?.old_site_issues || []).slice(0, 3).forEach((i) => lines.push(`- ${i.fix}`));
  lines.push('', 'Happy to walk you through it. Would 15 minutes this week work?');
  return lines.join('\n');
}
