# Pitch Site Builder

A sales tool for your team. A rep enters a prospect's name, website, industry and city, drops in their
logo, and about eight minutes later has:

- **A brand-new, award-level homepage** for that business, live at a shareable link
  (`https://mohammedkhan-socialordeals.github.io/<business-city>/`), in the spirit of
  aventuradentalarts.com and lavadental.lv, with full-bleed photography or video, editorial typography,
  and a page that moves as you scroll (details in [What every demo includes](#what-every-demo-includes))
- **A before/after Google PageSpeed scorecard** and a 26-point SEO / AEO / GEO / speed / credibility checklist
- **The problems on their current site**, ranked by what they cost the business
- **Their local competitors**, what each does better, and how the new site beats them
- **A website review page for the owner** (`.../report.html`)
- **Sharing tools**: QR code, text / email / WhatsApp buttons, and a branded preview card for the link
- **A ready-to-send message** to the owner

Every demo is saved as its own repo in your GitHub account.

---

## Setup checklist

Do these once. Total time: about 30–40 minutes.

- [ ] 1. [Claude API key](#1-claude-api-key) → `ANTHROPIC_API_KEY` (required)
- [ ] 2. [GitHub token](#2-github-token) → `GITHUB_TOKEN` and `GITHUB_OWNER` (required)
- [ ] 3. [Team password](#3-team-password) → `TEAM_PASSWORD` (required)
- [ ] 4. [Pexels key](#4-pexels-key) → `PEXELS_API_KEY` (strongly recommended: professional photos and video)
- [ ] 5. [Google Cloud key](#5-google-cloud-key) → `GOOGLE_PLACES_API_KEY` and `PAGESPEED_API_KEY` (strongly recommended: real reviews, hours, competitors, reliable speed tests)
- [ ] 6. [Optional settings](#6-optional-settings) (your agency name on reports, model choices)
- [ ] 7. [Deploy to Vercel](#deploy-to-vercel) and paste in the keys
- [ ] 8. [Test it](#check-that-everything-is-connected) with one real prospect

## All the keys at a glance

| Setting | Required? | What it powers | Cost | Where to get it |
|---|---|---|---|---|
| `ANTHROPIC_API_KEY` | Yes | All the AI: research, art direction, building every section | Pay as you go | platform.claude.com |
| `GITHUB_TOKEN` | Yes | Creating a repo per demo and publishing it on GitHub Pages | Free | github.com/settings/tokens |
| `GITHUB_OWNER` | Yes | Which GitHub account the demos go to | | `mohammedkhan-socialordeals` |
| `TEAM_PASSWORD` | Yes | Stops strangers from using your tool and credits | | You make it up |
| `PEXELS_API_KEY` | Strongly recommended | Professional stock photos and the hero video | Free | pexels.com/api |
| `GOOGLE_PLACES_API_KEY` | Strongly recommended | Real Google reviews, hours, "Open now", star ratings, nearby competitors | Monthly free allowance, then pay as you go | console.cloud.google.com |
| `PAGESPEED_API_KEY` | Strongly recommended | Speed tests that never hit Google's shared limit | Free | console.cloud.google.com (same key works) |
| `AGENCY_NAME`, `AGENCY_CONTACT`, `AGENCY_URL` | Optional | Your agency's name and contact details on the owner's report | | You write them |
| `CLAUDE_MODEL`, `CLAUDE_BUILD_MODEL` | Optional | Which Claude models to use | | See [Optional settings](#6-optional-settings) |
| `HERO_VIDEO`, `GITHUB_PRIVATE_REPOS`, `STEP_BUDGET_MS` | Optional | Fine-tuning | | See [Optional settings](#6-optional-settings) |

> **Never paste real keys into this README, into code, or into a chat.** They only go into Vercel's
> Environment Variables (or a local `.env.local` file, which is already excluded from Git).
> If a key ever leaks, delete it where you created it and make a new one.

---

## Getting each key

### 1. Claude API key

`ANTHROPIC_API_KEY`: powers every AI step.

1. Go to **https://platform.claude.com** and sign in or create an account. This is the Claude Console
   for developers. It's separate from a claude.ai chat subscription, so a Claude Pro plan doesn't include API usage.
2. Open **Settings → Billing**, add a payment method and buy some credits.
   Tip: set a monthly spend limit there so there are no surprises.
3. Open **Settings → API keys → Create key**. Name it `pitch-site-builder`.
4. Copy the key right away (it starts with `sk-ant-` and is only shown once).
5. **Turn on web search** (lets Claude research competitors and local customer questions):
   an organization admin opens **Settings → Privacy** in the Console and allows web search for the API.
   If you skip this, the tool still works; competitor research then relies on Google Maps data only.

Models used by default: **Claude Sonnet 5.5** for research (fast) and **Claude Opus 5.5** for the art
direction and every section (Anthropic's strongest model, where the design quality comes from).

### 2. GitHub token

`GITHUB_TOKEN`: lets the tool create a repo for each demo and turn on GitHub Pages.
`GITHUB_OWNER`: set it to `mohammedkhan-socialordeals`.

1. Sign in to GitHub as **mohammedkhan-socialordeals**.
2. Open **https://github.com/settings/tokens/new?scopes=repo&description=pitch-site-builder**
   (this is **Settings → Developer settings → Personal access tokens → Tokens (classic) → Generate new token**).
3. **Expiration:** choose 90 days or "No expiration" (if it expires, demos stop publishing until you
   make a new one).
4. **Scopes:** tick **repo** (the whole box). Nothing else is needed.
5. Click **Generate token** and copy it (starts with `ghp_`, only shown once).

Prefer a fine-grained token? Choose **Repository access: All repositories** and set
**Administration**, **Contents** and **Pages** to **Read and write**.

Demo repos are public by default because GitHub Pages on private repos needs a paid GitHub plan.

### 3. Team password

`TEAM_PASSWORD`: make up a password and share it with the sales team. Reps type it once in the tool and
it's remembered on that computer. Change it any time in Vercel (then redeploy).

### 4. Pexels key

`PEXELS_API_KEY`: professional, free-to-use stock photos and the hero background video. **This is the
single biggest upgrade to how premium the demos look.**

1. Create a free account at **https://www.pexels.com/join**.
2. Go to **https://www.pexels.com/api** and click **Your API Key** (or "Get started").
3. Fill in the short form (for example, "Website previews for small-business clients") and accept the terms.
4. Copy the key shown on the page.

Free. Pexels limits requests per hour and per month (by default about 200 per hour); each demo uses
about 7. Photos are free to use under the Pexels license; each demo repo lists the photographers in `CREDITS.md`.

### 5. Google Cloud key

One key covers both `GOOGLE_PLACES_API_KEY` and `PAGESPEED_API_KEY`.

1. Go to **https://console.cloud.google.com** and sign in with a Google account.
2. At the top, click the project picker → **New project** → name it `pitch-site-builder` → **Create**,
   then make sure it's selected.
3. **Turn on billing** (required for the Places API): **Billing → Link a billing account** and add a card.
   Google gives a monthly free usage allowance for Maps APIs; check current pricing at
   https://mapsplatform.google.com/pricing. Set a **budget alert** under **Billing → Budgets & alerts**.
4. Open **APIs & Services → Library** and enable both:
   - **Places API (New)** (make sure it says "New")
   - **PageSpeed Insights API**
5. Open **APIs & Services → Credentials → Create credentials → API key**. Copy the key.
6. Click the new key to edit it. Under **API restrictions**, choose **Restrict key** and tick
   **Places API (New)** and **PageSpeed Insights API**. Leave **Application restrictions** as **None**
   (the tool calls Google from its server). Save.
7. Paste the same key into both `GOOGLE_PLACES_API_KEY` and `PAGESPEED_API_KEY`.

What it unlocks: the prospect's real Google reviews quoted on their new site, their hours and a live
"Open now" badge, accurate address and map link, star ratings for competitors, and speed tests that
never fail with "quota exceeded".

### 6. Optional settings

| Setting | Example | What it does |
|---|---|---|
| `AGENCY_NAME` | `Social or Deals` | "Prepared by" on the owner's report |
| `AGENCY_CONTACT` | `Mohammed Khan, (555) 555-0100, hello@yourdomain.com` | Contact line on the report |
| `AGENCY_URL` | `https://yourdomain.com` | Links your name on the report |
| `CLAUDE_MODEL` | `claude-sonnet-5-5` (default) | Model for research |
| `CLAUDE_BUILD_MODEL` | `claude-opus-5-5` (default) | Model for art direction and sections. `claude-sonnet-5-5` is faster and cheaper with slightly less refined designs |
| `HERO_VIDEO` | `true` (default) | Set to `false` to never use a background video |
| `GITHUB_PRIVATE_REPOS` | `false` (default) | `true` makes demo repos private (needs a paid GitHub plan for Pages) |
| `STEP_BUDGET_MS` | `285000` (default) | How long one AI step may run; raise to `780000` on Vercel Pro (see [Time limits](#time-limits)) |

---

## Deploy to Vercel

1. **Put this code on GitHub.** Create a **private** repo in your account (for example
   `pitch-site-builder`) and upload the contents of this folder (drag and drop on github.com works,
   or use `git push`). Don't upload `node_modules` or any `.env` file.
2. Go to **https://vercel.com/new**, sign in with GitHub, and **Import** that repo.
   Vercel detects Next.js automatically; leave the build settings as they are.
3. Before clicking Deploy, open **Environment Variables** and add each setting from the table above,
   one per row (name on the left, value on the right). At minimum: `ANTHROPIC_API_KEY`,
   `GITHUB_TOKEN`, `GITHUB_OWNER`, `TEAM_PASSWORD`; ideally also `PEXELS_API_KEY`,
   `GOOGLE_PLACES_API_KEY`, `PAGESPEED_API_KEY`.
4. Click **Deploy**. You'll get a link like `pitch-site-builder.vercel.app`.
5. Share that link and the team password with your reps.

**Changing a key later:** Vercel → your project → **Settings → Environment Variables** → edit →
then **Deployments → ⋯ → Redeploy**. Changes only apply after a redeploy.

### Check that everything is connected

Open the tool. The box under the Build button lists anything that's missing. For a precise check,
open `https://<your-app>.vercel.app/api/config`. It shows `true`/`false` for each key (never the
values themselves). Then run one real prospect end to end.

### Run it on your own computer instead

Needs Node.js 20 or newer.

```bash
cp .env.example .env.local   # then open .env.local and fill in the keys
npm install
npm run dev                  # open http://localhost:3000
```

---

## Using it (for the sales team)

1. Open the tool and enter the team password once.
2. Fill in business name, current website, what they do, and city and state. Add the logo (PNG, JPG,
   WebP or SVG; a transparent PNG works best). Add notes if the owner said anything useful
   ("wants a dark, luxurious look", "push implants", "free parking").
3. Press **Build demo site**. You'll watch the art direction being written, then the page fill in
   section by section on the blue stage.
4. Check it on the **Phone** view. If a section isn't right, press **Rewrite** next to it in the
   Sections list, type what should change ("bigger photo", "mention financing", "darker"), then press
   **Publish changes**.
5. Share it: show the **QR code** in a meeting, or use **Copy link / Text it / Email it / WhatsApp**.
   The message to the owner further down includes the site link and the report link.
6. If a step fails, press **Retry this step**. Earlier steps aren't repeated, and a failed build only
   rebuilds the parts that failed.

Building the same business again updates the same repo and link.

---

## What every demo includes

**Design.** Claude Opus studies the logo and every photo, then sets a palette from the brand colors,
two deliberate Google Fonts, a fluid type scale and a 9–12 section plan modeled on the best premium
local-business sites. Every section is then written by its own Opus pass using that shared design system.

**Interactions (the "alive" feeling).** Each demo choreographs at least seven signature moments,
a different one per section:
- headline words rising in, the hero photo easing in, and the hero zooming and fading as you scroll away
- a manifesto whose words light up as you scroll through it
- a pinned section where service cards slide sideways as you scroll down (swipeable on phones)
- a service list where a photo floats beside the cursor as you hover each row
- process cards that stack and dim as the next one slides over
- magnetic buttons, 3D tilt cards and a cursor spotlight on dark sections
- an optional custom cursor that grows over links
- tabs, carousels with "01 / 06" counters, count-up stats, and marquees that speed up as you scroll
- a full-screen photo lightbox, before/after sliders (only with real before/after photos)
- a live "Open now until 5 pm" badge from their Google hours
- a scroll-progress line in the header, a full-screen mobile menu, and a sticky call/book bar on phones
- an optional slow background video in the hero (desktop only)

All of this comes from a built-in 15 KB script (`lib/runtime.js`). Claude only switches effects on;
it never writes JavaScript. Everything still works on phones, without a mouse, and for visitors who
turn on "reduce motion".

**Speed.** One HTML file, no frameworks, fonts that don't block the page, every photo compressed to
WebP in two sizes, the hero photo preloaded, everything else lazy-loaded with exact dimensions, and the
video loaded only on desktop after the page is ready. Aim: 90+ on mobile PageSpeed.

**SEO.** Keyword + city title and description, one H1, canonical tag pointing to their real domain (so
the demo never competes with their live site), Open Graph tags, sitemap, robots.txt, alt text.

**AEO (answer engines).** A one-sentence answer about the business near the top, an FAQ written from
real local customer questions, and FAQ structured data that matches the visible answers word for word.

**GEO (ChatGPT, Claude, Perplexity, Gemini).** LocalBusiness structured data with the most specific type
(Dentist, Plumber...), services, service area, hours, social profiles and map link; an `llms.txt`
summary; robots.txt that welcomes AI crawlers.

**Credibility.** Real Google reviews quoted word for word with names, the current year, visible address
and hours, clear calls to action. The prompts forbid inventing facts, numbers, awards or testimonials,
and stock photos are never presented as the real team, patients or premises.

---

## How it works

```
1. Scan          their site, Google speed test + screenshot, Google profile (rating, hours, reviews),
                 nearby competitors (each competitor's homepage is checked too)
2. Research      Claude Sonnet studies the audit, searches the web, plans the rebuild, picks photo searches
3. Photography   their own photos + Pexels stock photos and a hero video, compressed
4. Art direction Claude Opus writes the design system, the section plan and each section's interactions
5. Build         header/footer and every section written at the same time (4 in parallel)
6. Publish       final page with responsive images, share image, robots.txt, sitemap.xml, llms.txt;
                 one commit to a new GitHub repo; GitHub Pages switched on
7. Re-test       the same PageSpeed test on the new site
8. Report        report.html (the owner's before/after review) added to the repo
```

The title, meta tags, canonical, structured data, image markup and FAQ markup are generated in code
(`lib/assemble.js`), not by the AI, so they're correct on every demo.

## Customizing

- **The premium patterns and choreography:** `DESIGN_SYSTEM` in `lib/prompts.js` ("THE BAR" and "CHOREOGRAPHY").
- **Section writing rules:** `SECTION_SYSTEM`. **Header and footer:** `CHROME_SYSTEM`.
- **Available effects:** `lib/runtime.js` (the text at the top is exactly what Claude reads).
- **Checklist items:** `lib/checklist.js`; owner-friendly wording in `OWNER_LABELS` in `lib/report.js`.
- **Owner's report layout:** `lib/report.js`.
- **Photos (how many, sizes, compression):** top of `lib/library.js`.

## Time limits

Each step is designed to finish within Vercel's free 5-minute limit, which is why the build is split
into many small parallel calls. The slowest step is the art direction on Opus (usually 2–4 minutes).
If you see "This step ran out of time":
- On **Vercel Pro**, change `maxDuration` from `300` to `800` in each file under `app/api/` and set
  `STEP_BUDGET_MS=780000`, or
- set `CLAUDE_BUILD_MODEL=claude-sonnet-5-5` (faster and cheaper, slightly less refined).

## Cost

Each demo makes about a dozen Claude calls (one research call with web search, one art direction call,
and one per section, mostly on Opus) plus a few Google and Pexels requests. Check current prices at
https://www.anthropic.com/pricing, and watch the Usage page in the Claude Console for your first demos.

## When a prospect says yes

The repo already has everything for launch. Either point their domain at the GitHub Pages site
(repo → **Settings → Pages → Custom domain**) or upload the files to their existing host. The canonical
tag, sitemap and robots.txt already use their real domain. Before launch:
- delete `report.html` and `assets/before.jpg` / `assets/after.jpg` (they're only for the pitch)
- swap stock photos for real photos of the business where you can (credits are in `CREDITS.md`)

## Troubleshooting

| Message | Fix |
|---|---|
| "Wrong team password" | Check `TEAM_PASSWORD` in Vercel, then redeploy. |
| "Claude rejected the API key" | Re-copy `ANTHROPIC_API_KEY` from platform.claude.com → Settings → API keys, then redeploy. |
| "Your Claude API account is out of credits" | platform.claude.com → Settings → Billing → add credits. |
| "Claude is busy right now" / "Too many builds at once" | Wait a minute, press Retry. |
| "This step ran out of time" | See [Time limits](#time-limits). |
| "GitHub couldn't sign in" / "token is wrong or expired" | Make a new token (step 2) and update `GITHUB_TOKEN`. |
| "GitHub couldn't create the repository" | The token needs the **repo** scope, and `GITHUB_OWNER` must be the account the token belongs to. |
| "GitHub Pages is still deploying" | First deploys take 1–2 minutes. Press Retry on the speed step; it republishes the report too. |
| "Professional photography is off" | Add `PEXELS_API_KEY`, redeploy. |
| "Google data is off" / no reviews on demos | Add `GOOGLE_PLACES_API_KEY`; make sure **Places API (New)** is enabled and billing is on. |
| "Google Places: ... not authorized" | The key's API restrictions must include **Places API (New)**. |
| "PageSpeed's free daily limit is used up" | Add `PAGESPEED_API_KEY` and enable **PageSpeed Insights API**. |
| "The site answered with status 403" | Their site blocks bots. The tool continues; Claude researches the business online instead. |
| A section looks off | Press **Rewrite** next to it with a note, then **Publish changes**. |
